export async function getData() {
	let promise = new Promise(async (resolve) => {
		let data = {
			products: {},
			groups_by_id: {}
		};

		let url = 'index.json';
		let response = await fetch(url);
		let result = await response.json();

		data.products = result;

		for (let index_group = 0; index_group < data.products.groups.length; ++index_group) {
			let group = data.products.groups[index_group];
			data.groups_by_id[group.id] = group;
		}

		resolve(data);
	});

	return promise;
}