import ListCards from './views/list-cards.js';
import CardProduct from './views/card-product.js';

async function start() {
	const model = await import('./model-main.js');

	let data = await model.getData();
	let groups = data.products.groups;
	let main = document.getElementById('main');
	
	new ListCards(groups, CardProduct, main);
}

start();