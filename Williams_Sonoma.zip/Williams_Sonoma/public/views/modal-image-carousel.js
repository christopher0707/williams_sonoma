import Modal from './modal.js';

export default class ModalImageCarousel extends Modal {
	constructor(group, container = null) {
		super(group, container);

		let dom = this.genDom();
		this.elem.classList.add('ghost');
		this.content.innerHTML = dom;

		let clickNavShift = (event) => {
			let nav = event.currentTarget;
			let shift = parseInt(nav.dataset.shift);

			this.shift(shift);

			return false;
		};

		this.image_main = document.getElementById('carousel_image_main');
		this.nav_prev = document.getElementById('carousel_nav_prev');
		this.nav_prev.onclick = clickNavShift;
		this.nav_next = document.getElementById('carousel_nav_next');
		this.nav_next.onclick = clickNavShift;

		this.nav_images = [];
		for (let index_nav = 0; index_nav < 5; ++index_nav) {
			let nav = document.getElementById(`carousel_nav_${index_nav}`);
			nav.onclick = clickNavShift;
			this.nav_images.push(nav);
		}

		this.image_urls = [];
		this.image_urls.push(group.hero.href);
		for (let index_image = 0; index_image < group.images.length; ++index_image) {
			let image = group.images[index_image];
			this.image_urls.push(image.href);
		}

		this.index = 0;
		this.displayImage(this.index);
	}

	shift(shift) {
		this.index += shift;
		if (this.index < 0)
			this.index = 0;
		else
		if (this.index >= this.image_urls.length)
			this.index = this.image_urls.length - 1;

		this.displayImage(this.index);
	}

	displayImage(index) {
		while (index < 0)
			index += this.image_urls.length;
		while (index >= this.image_urls.length)
			index -= this.image_urls.length;

		this.image_main.src = this.image_urls[index];

		let index_image = index - 2;
		
		for (let index_nav = 0; index_nav < this.nav_images.length; ++index_nav) {
			let elem_nav = this.nav_images[index_nav];
			let elem_image = elem_nav.getElementsByTagName('img')[0];

			if (index_image < 0 || index_image >= this.image_urls.length) {
				elem_nav.dataset.empty = true;
				elem_image.src = '';
			} else {
				elem_nav.dataset.empty = false;
				elem_image.src = this.image_urls[index_image];
			}

			++index_image;
		}

		this.nav_prev.dataset.empty = index <= 0;
		this.nav_next.dataset.empty = index >= this.image_urls.length - 1;
	}

	genDom() {
		let dom =
			`<div class="image-carousel">
				<div class="main">
					<img id="carousel_image_main" src="" />
				</div>
				<pivot id="carousel_nav_prev" class="nav-prev" data-shift="-1" data-empty="false">
					<nav>
						<span>&#x25B2;</span>
					</nav>
				</pivot>
				<pivot id="carousel_nav_0" class="nav-0" data-shift="-2" data-empty="false">
					<nav>
						<img id="carousel_image_nav_0" src="" />
					</nav>
				</pivot>
				<pivot id="carousel_nav_1" class="nav-1" data-shift="-1" data-empty="false">
					<nav>
						<img id="carousel_image_nav_1" src="" />
					</nav>
				</pivot>
				<pivot id="carousel_nav_2" class="nav-2" data-shift="0" data-empty="false" data-selected="true">
					<nav>
						<img id="carousel_image_nav_2" src="" />
					</nav>
				</pivot>
				<pivot id="carousel_nav_3" class="nav-3" data-shift="1" data-empty="false">
					<nav>
						<img id="carousel_image_nav_3" src="" />
					</nav>
				</pivot>
				<pivot id="carousel_nav_4" class="nav-4" data-shift="2" data-empty="false">
					<nav>
						<img id="carousel_image_nav_4" src="" />
					</nav>
				</pivot>
				<pivot id="carousel_nav_next" class="nav-next" data-shift="1" data-empty="false">
					<nav>
						<span>&#x25B6;</span>
					</nav>
				</pivot>
			</div>`;

		return dom;
	}
}