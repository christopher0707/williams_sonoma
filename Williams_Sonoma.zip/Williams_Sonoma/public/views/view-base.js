export default class ViewBase {
	constructor(container = null) {
		if (!container)
			container = document.body;

		this.container = container;
	}

	destroy() {
	
	}
}