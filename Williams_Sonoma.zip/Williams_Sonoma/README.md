## Run

1. install node.js via official website and open your command line (terminal fo
   r MacOS) then navigate to the project folder, if the server is running succe
   ssfully, you should see the following output:

   Server live
   Listening on port 80

2. once the server is up and running, open the browser and type localhost in th
   e address bar, the UI widget should show up directly 